# FOCUS LOCK (Android starter)

## Requirements
- Android Studio (current stable)
- JDK 17
- Android phone running Android 6.0 or later

## Open and build
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the `FocusLock` folder.
3. Let Gradle sync and install any requested Android SDK 35 components.
4. Connect your Android phone with USB debugging enabled.
5. Press Run, or use Build > Build Bundle(s) / APK(s) > Build APK(s).

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## First launch
1. Open FOCUS LOCK.
2. Tap **ENABLE ACCESSIBILITY BLOCKING**.
3. In Android Accessibility settings, open FOCUS LOCK and enable its service.
4. Return to FOCUS LOCK.
5. Select apps, tap SAVE APP SELECTION, choose a duration and start.

## Important limitations
This is a personal-device starter, not a tamper-proof parental-control or kiosk solution.
A user who controls the phone can disable Accessibility, force-stop/uninstall the app,
revoke permissions, or reboot into other system screens. Some OEM Android versions
may delay or suppress app-launch events. Test on your own device.

For true managed-device enforcement, implement a Device Policy Controller (DPC),
provision the device as Device Owner, and use Android Lock Task Mode with a carefully
designed allowlist. Device Owner provisioning can require a factory reset and is not
appropriate for an ordinary install on an already configured personal phone.

The app uses QUERY_ALL_PACKAGES only for package visibility compatibility if you later
extend the picker to installed apps. The current picker contains the seven requested apps.
