package com.example.focuslock

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var timerText: TextView
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private data class AppChoice(val name: String, val pkg: String)
    private val targets = listOf(
        AppChoice("Instagram", "com.instagram.android"),
        AppChoice("Facebook", "com.facebook.katana"),
        AppChoice("YouTube", "com.google.android.youtube"),
        AppChoice("Snapchat", "com.snapchat.android"),
        AppChoice("WhatsApp", "com.whatsapp"),
        AppChoice("Telegram", "org.telegram.messenger"),
        AppChoice("Chrome", "com.android.chrome")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                gravity = Gravity.CENTER
            }

        root.addView(text("FOCUS LOCK", 27f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("Stay focused. Block distractions.", 14f, 0xFFB7C4D8.toInt()))
        timerText = text("00:00:00", 42f, 0xFF65E6B2.toInt(), true)
        val timerParams = LinearLayout.LayoutParams(-1, 180)
        timerParams.topMargin = 22
        root.addView(timerText, timerParams)
        statusText = text("No active focus session", 15f, 0xFFCFD8E6.toInt())
        root.addView(statusText)

        val duration = EditText(this).apply {
            hint = "Focus duration in minutes (e.g. 60)"
            setHintTextColor(0xFF9AA9BD.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine()
            inputType = 2
            setText("60")
        }
        val dparams = LinearLayout.LayoutParams(-1, 54)
        dparams.topMargin = 24
        root.addView(duration, dparams)

        val heading = text("SELECT APPS TO BLOCK", 17f, 0xFFFFFFFF.toInt(), true)
        heading.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        val hparams = LinearLayout.LayoutParams(-1, 54)
        root.addView(heading, hparams)

        val saved = SessionStore.selected(this)
        targets.forEach { app ->
            val check = CheckBox(this).apply {
                text = app.name
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
                buttonTintList = android.content.res.ColorStateList.valueOf(0xFF65E6B2.toInt())
                isChecked = saved.contains(app.pkg)
                isEnabled = !SessionStore.isActive(this@MainActivity)
                tag = app.pkg
            }
            root.addView(check)
        }

        val saveButton = Button(this).apply {
            text = "SAVE APP SELECTION"
            setOnClickListener {
                val selected = (0 until root.childCount).mapNotNull { root.getChildAt(it) }
                    .filterIsInstance<CheckBox>().filter { it.isChecked }
                    .mapNotNull { it.tag as? String }.toSet()
                SessionStore.saveSelected(this@MainActivity, selected)
                Toast.makeText(this@MainActivity, "App selection saved", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(saveButton)

        val accessButton = Button(this).apply {
            text = "ENABLE ACCESSIBILITY BLOCKING"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessButton)

        startButton = Button(this).apply {
            text = "START FOCUS SESSION"
            setOnClickListener {
                val selected = SessionStore.selected(this@MainActivity)
                if (selected.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Select at least one app and save.", Toast.LENGTH_LONG).show()
                } else if (!FocusAccessibilityService.isEnabled(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Enable FOCUS LOCK in Accessibility settings first.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else {
                    val mins = duration.text.toString().toIntOrNull()
                    if (mins == null || mins !in 1..1440) {
                        Toast.makeText(this@MainActivity, "Enter 1 to 1440 minutes.", Toast.LENGTH_SHORT).show()
                    } else {
                        SessionStore.start(this@MainActivity, mins)
                        refresh()
                    }
                }
            }
        }
        root.addView(startButton)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refresh() {
        val active = SessionStore.isActive(this)
        val ms = SessionStore.remainingMillis(this)
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val mins = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val secs = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        timerText.text = String.format("%02d:%02d:%02d", hours, mins, secs)
        statusText.text = if (active) "FOCUS SESSION ACTIVE" else "No active focus session"
        startButton.text = if (active) "SESSION RUNNING" else "START FOCUS SESSION"
        startButton.isEnabled = !active
        if (SessionStore.prefs(this).getBoolean("active", false) && ms == 0L) {
            SessionStore.stop(this)
            statusText.text = "Session complete. Apps unlocked!"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
