package com.example.focuslock

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.TimeUnit

class BlockActivity : Activity() {
    private lateinit var timer: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val update = object : Runnable {
        override fun run() {
            val left = SessionStore.remainingMillis(this@BlockActivity)
            if (!SessionStore.isActive(this@BlockActivity) || left <= 0L) {
                SessionStore.stop(this@BlockActivity)
                finish()
                return
            }
            val h = TimeUnit.MILLISECONDS.toHours(left)
            val m = TimeUnit.MILLISECONDS.toMinutes(left) % 60
            val s = TimeUnit.MILLISECONDS.toSeconds(left) % 60
            timer.text = String.format("%02d:%02d:%02d", h, m, s)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "FOCUS SESSION ACTIVE"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        timer = TextView(this).apply {
            textSize = 38f
            setTextColor(0xFF65E6B2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        }
        val message = TextView(this).apply {
            text = "This app is blocked until your focus session ends.\nReturn to your task — you've got this."
            textSize = 17f
            setTextColor(0xFFCFD8E6.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(timer)
        root.addView(message)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        handler.post(update)
    }

    override fun onPause() {
        handler.removeCallbacks(update)
        super.onPause()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        // Intentionally remain on the blocking screen during the session.
    }
}
