package com.example.focuslock

import android.content.Context

object SessionStore {
    private const val PREF = "focus_lock"
    private const val END = "end_time"
    private const val SELECTED = "selected_apps"
    private const val ACTIVE = "active"

    fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun isActive(context: Context) = prefs(context).getBoolean(ACTIVE, false) &&
        prefs(context).getLong(END, 0L) > System.currentTimeMillis()

    fun endTime(context: Context) = prefs(context).getLong(END, 0L)
    fun selected(context: Context): Set<String> =
        prefs(context).getStringSet(SELECTED, emptySet())?.toSet() ?: emptySet()

    fun saveSelected(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(SELECTED, packages).apply()
    }

    fun start(context: Context, minutes: Int) {
        prefs(context).edit()
            .putLong(END, System.currentTimeMillis() + minutes * 60_000L)
            .putBoolean(ACTIVE, true).apply()
    }

    fun stop(context: Context) {
        prefs(context).edit().putBoolean(ACTIVE, false).putLong(END, 0L).apply()
    }

    fun remainingMillis(context: Context): Long =
        (endTime(context) - System.currentTimeMillis()).coerceAtLeast(0L)
}
